import { handleSubmit } from "../src/client/js/formHandler"

    // The describe() function  
    describe("Testing the submit functionality", () => {
        // The test() function 
        test("Testing the handleSubmit() function", () => {
               // Define the input for the function, if any, in the form of variables/array
               // Define the expected output, if any, in the form of variables/array
               expect(handleSubmit).toBeDefined();
    })});