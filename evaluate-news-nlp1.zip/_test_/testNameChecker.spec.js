import { checkForName } from "../src/client/js/nameChecker"

    // The describe() function  
    describe("Testing the name checking functionality", () => {
        // The test() function 
        test("Testing the checkForName() function", () => {
               // Define the input for the function, if any, in the form of variables/array
               // Define the expected output, if any, in the form of variables/array
               expect(checkForName).toBeDefined();
    })});