# Evaluate News NLP Project #4

## Table of Contents

* [Description](#description)
* [Author](#author)

## Description
This project was completed as a part of the Front End Nanodegree program offered by Udacity.

## Author

This project was written by Yusrah Shaikh with the starter code given by Udacity. 